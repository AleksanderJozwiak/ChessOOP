#pragma once
int n;