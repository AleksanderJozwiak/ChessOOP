#include "Knight.h"
bool Knight::checkMove(Figure* f[]) {

	for (int i = 0; i < 48; i++)
	{
		if (newPos == f[i]->oldPos && _color == f[i]->_color)
			return false;
	}
	if (newPos.x >= 1000 || newPos.x < 0 || newPos.y >= 1000 || newPos.y < 0)
		return false;
	/*
		if (newPos.y == oldPos.y + (size * 2) && newPos.x == oldPos.x + size)
			return true;
		if (newPos.y == oldPos.y + (size*2) && newPos.x == oldPos.x - size)
			return true;
		if (newPos.y == oldPos.y - (size*2) && newPos.x == oldPos.x + size)
			return true;
		if (newPos.y == oldPos.y - (size*2) && newPos.x == oldPos.x - size)
			return true;
		if (newPos.y == oldPos.y + size && newPos.x == oldPos.x + (size * 2))
			return true;
		if (newPos.y == oldPos.y - size && newPos.x == oldPos.x + (size * 2))
			return true;
		if (newPos.y == oldPos.y + size && newPos.x == oldPos.x - (size * 2))
			return true;
		if (newPos.y == oldPos.y - size && newPos.x == oldPos.x - (size * 2))
			return true;
	*/

	if (newPos == oldPos + sf::Vector2f(size, size * 2))
		return true;
	if (newPos == oldPos + sf::Vector2f(-size, size * 2))
		return true;
	if (newPos == oldPos + sf::Vector2f(size, -size * 2))
		return true;
	if (newPos == oldPos + sf::Vector2f(-size, -size * 2))
		return true;
	if (newPos == oldPos + sf::Vector2f(size * 2, size))
		return true;
	if (newPos == oldPos + sf::Vector2f(size * 2, -size))
		return true;
	if (newPos == oldPos + sf::Vector2f(-size * 2, size))
		return true;
	if (newPos == oldPos + sf::Vector2f(-size * 2, -size))
		return true;
	
	return false;

}